1. Steps to disable ASLR
echo 0 | sudo tee /proc/sys/kernel/randomize_va_space

2. Steps to disable W^X
Install execstack tool that removes the NX bit from executables.
Use the makefile provided as it has already added the flags to disable W^X:
gcc -fno-stack-protector -z execstack -o your_executable your_source.c 

3. Add the following line to the buffer content inside attack.asm to print the message.
mov rax, 1 //Make system call for write
mov rdi, 1 //Stdout file handle
mov rdx, message_len // The length of the message
mov rsi, buffer_ptr+message-$$ // The absolute address of the message to print
syscall
